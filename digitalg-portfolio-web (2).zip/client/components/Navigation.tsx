import { Link } from "react-router-dom";
import { Menu, X } from "lucide-react";
import { useState } from "react";

export default function Navigation() {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <nav className="fixed w-full h-[65px] top-0 z-50 bg-slate-900/60 backdrop-blur-md border-b border-slate-700/50">
      <div className="max-w-7xl mx-auto mt-1.5 px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-35">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-2 group">
            <div
              className="w-[128px] h-[50px] bg-cover bg-center bg-no-repeat"
              style={{
                backgroundImage: "url(https://cdn.builder.io/api/v1/image/assets%2F39d0ba7f4d124b029f9431f62938559a%2Fa7dc8552420442259bb44470debf46ee)"
              }}
            />
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center gap-8">
            <a
              href="#work"
              className="text-slate-300 hover:text-slate-100 transition-colors font-spartan font-medium text-lg"
            >
              Creatividad y Diseño
            </a>
            <a
              href="#about"
              className="text-slate-300 hover:text-slate-100 transition-colors font-spartan font-medium text-lg"
            >
              Social Media Strategy
            </a>
            <a
              href="#services"
              className="text-slate-300 hover:text-slate-100 transition-colors font-spartan font-medium text-lg"
            >
              Quiénes Somos
            </a>
            <a
              href="#contact"
              className="bg-[#ffa546] text-white px-6 py-2 rounded-lg hover:bg-orange-600 transition-colors font-spartan font-medium text-lg"
            >
              Contáctanos
            </a>
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsOpen(!isOpen)}
            className="md:hidden p-2 rounded-lg hover:bg-slate-800 transition-colors"
          >
            {isOpen ? (
              <X className="w-6 h-6 text-slate-100" />
            ) : (
              <Menu className="w-6 h-6 text-slate-100" />
            )}
          </button>
        </div>

        {/* Mobile Navigation */}
        {isOpen && (
          <div className="md:hidden pb-4 border-t border-slate-700">
            <a
              href="#work"
              className="block px-4 py-2 text-slate-300 hover:text-slate-100 transition-colors font-spartan font-medium text-lg"
              onClick={() => setIsOpen(false)}
            >
              Creatividad y Diseño
            </a>
            <a
              href="#about"
              className="block px-4 py-2 text-slate-300 hover:text-slate-100 transition-colors font-spartan font-medium text-lg"
              onClick={() => setIsOpen(false)}
            >
              Social Media Strategy
            </a>
            <a
              href="#services"
              className="block px-4 py-2 text-slate-300 hover:text-slate-100 transition-colors font-spartan font-medium text-lg"
              onClick={() => setIsOpen(false)}
            >
              Quiénes Somos
            </a>
            <div className="px-4 py-2">
              <button className="w-full bg-[#ffa546] text-white px-6 py-2 rounded-lg hover:bg-orange-600 transition-colors font-spartan font-medium text-lg">
                Contáctanos
              </button>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
}
