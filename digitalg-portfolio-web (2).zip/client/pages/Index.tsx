import Navigation from "@/components/Navigation";
import {
  ArrowRight,
  Zap,
  Palette,
  Code,
  Award,
  CheckCircle,
} from "lucide-react";

export default function Index() {
  const projects = [
    {
      id: 1,
      title: "Diseño y Creatividad",
      category: "UI/UX Design",
      image:
        "https://static.wixstatic.com/media/108b40_0a0d3b9bc495400c8f21032f8a057eab~mv2.jpeg/v1/crop/x_1302,y_0,w_4757,h_4912/fill/w_702,h_726,fp_0.50_0.50,q_85,usm_0.66_1.00_0.01,enc_avif,quality_auto/Dise%C3%B1o.jpeg",
      tags: ["Estáticas", "HTML5", "Vídeo", "Ejecución Creativa", "Web", "+10"],
    },
    {
      id: 2,
      title: "Social Media Strategy",
      category: "Product Design",
      image:
        "https://static.wixstatic.com/media/108b40_828bc57e90084b8f85eadedf50b05ddc~mv2.jpeg/v1/fill/w_842,h_870,fp_0.50_0.50,q_85,usm_0.66_1.00_0.01,enc_avif,quality_auto/Social.jpeg",
      tags: ["Estrategias", "Influencers", "UGC", "Reporting", "Casos de Éxito"],
    },
  ];

  const services = [
    {
      icon: Palette,
      title: "+15 años de experiencia",
      description:
        "Digital Group fue fundada en 2008.",
    },
    {
      icon: Award,
      title: "1ª Agencia Digital",
      description:
        "En España, según El Publicista (2024).",
    },
    {
      icon: Zap,
      title: "Más de 400 clientes",
      description:
        "Han confiado en nosotros.",
    },
    {
      icon: Code,
      title: "360º de Visión Digital",
      description:
        "Ofrecemos un servicio integral.",
    },
  ];

  const testimonials = [
    {
      quote:
        "Working with this team transformed our entire digital presence. Truly exceptional work.",
      author: "Sarah Johnson",
      role: "CEO, TechStart Inc",
    },
    {
      quote:
        "The attention to detail and creative thinking exceeded all our expectations.",
      author: "Michael Chen",
      role: "Product Manager, InnovateLabs",
    },
    {
      quote:
        "Best investment we made for our brand. Highly recommend to anyone.",
      author: "Emma Wilson",
      role: "Founder, Creative Studio",
    },
  ];

  return (
    <div className="min-h-screen bg-slate-900">
      <Navigation />

      {/* Video Hero Section */}
      <section className="relative w-full h-screen flex items-center justify-center overflow-hidden">
        {/* Video Background */}
        <div className="absolute inset-0 w-full h-full">
          <video
            autoPlay
            muted
            loop
            playsInline
            className="w-full h-full object-cover object-center"
          >
            <source
              src="https://video.wixstatic.com/video/bf73f8_0dc0beeb4aed4538b1a0f6b8986e46f5/1080p/mp4/file.mp4"
              type="video/mp4"
            />
          </video>
          {/* Dark overlay */}
          <div className="absolute inset-0 bg-black/0"></div>
        </div>

      </section>

      {/* Work Section */}
      <section id="work" className="py-14 px-4 bg-slate-800">
        <div className="max-w-7xl mx-auto">
          

          <div className="grid md:grid-cols-2 gap-8">
            {projects.map((project) => (
              <div
                key={project.id}
                className="group overflow-hidden rounded-xl bg-slate-700 hover:shadow-2xl transition-all duration-300 relative"
              >
                {/* Background Image */}
                <div className="absolute inset-0">
                  <img
                    src={project.image}
                    alt={project.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  {/* Gradient overlay for text readability */}
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/50 to-black/30" />
                </div>

                {/* Content with text over image */}
                <div className="relative z-10 p-6 h-full flex flex-col justify-end min-h-[320px]">
                  <p className="text-sm font-semibold text-blue-400 mb-2">
                    {project.category}
                  </p>
                  <h3 className="text-2xl font-bold text-white mb-4">
                    {project.title}
                  </h3>
                  <div className="flex flex-wrap gap-2">
                    {project.tags.map((tag) => (
                      <span
                        key={tag}
                        className="px-3 py-1 bg-white/20 backdrop-blur-sm text-white rounded-full text-sm"
                      >
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="text-center mt-12">
            <button className="px-8 py-3 text-blue-400 border-2 border-blue-500 rounded-lg hover:bg-blue-500/10 transition-colors font-semibold flex items-center justify-center gap-2 mx-auto">
              View All Projects
              <ArrowRight className="w-5 h-5" />
            </button>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section id="services" className="py-20 px-4 bg-slate-900">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-slate-50 mb-4">
              Services
            </h2>
            <p className="text-lg text-slate-300 max-w-2xl mx-auto">
              Comprehensive solutions to bring your vision to life.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {services.map((service, index) => {
              const Icon = service.icon;
              return (
                <div
                  key={index}
                  className="p-6 bg-slate-800 rounded-xl hover:shadow-lg transition-all duration-300 group border border-slate-700"
                >
                  <div className="w-12 h-12 bg-blue-900/40 rounded-lg flex items-center justify-center mb-4 group-hover:bg-blue-600 transition-colors">
                    <Icon className="w-6 h-6 text-blue-400 group-hover:text-white transition-colors" />
                  </div>
                  <h3 className="text-lg font-semibold text-slate-50 mb-2">
                    {service.title}
                  </h3>
                  <p className="text-slate-300 text-sm leading-relaxed">
                    {service.description}
                  </p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-20 px-4 bg-slate-800">
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <img
                src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=600&h=600&fit=crop"
                alt="About"
                className="rounded-2xl w-full"
              />
            </div>
            <div>
              <h2 className="text-4xl md:text-5xl font-bold text-slate-50 mb-6">
                About Me
              </h2>
              <p className="text-slate-300 text-lg mb-4 leading-relaxed">
                I'm a designer and developer with a passion for creating
                beautiful, functional digital experiences. With over 8 years of
                experience, I've had the privilege of working with amazing
                brands and teams.
              </p>
              <p className="text-slate-300 text-lg mb-8 leading-relaxed">
                My approach combines creative thinking with strategic planning
                to deliver solutions that not only look great but also drive
                real business results.
              </p>

              <div className="space-y-4">
                {[
                  "Full-stack design expertise",
                  "Data-driven approach",
                  "Proven track record",
                  "Always learning & growing",
                ].map((item) => (
                  <div key={item} className="flex items-center gap-3">
                    <CheckCircle className="w-5 h-5 text-blue-400 flex-shrink-0" />
                    <span className="text-slate-200">{item}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-20 px-4 bg-slate-900">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-slate-50 mb-4">
              What Clients Say
            </h2>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <div
                key={index}
                className="p-8 bg-slate-800 rounded-xl shadow-sm hover:shadow-lg transition-all duration-300 border border-slate-700"
              >
                <div className="flex gap-1 mb-4">
                  {[...Array(5)].map((_, i) => (
                    <span key={i} className="text-yellow-500">
                      ★
                    </span>
                  ))}
                </div>
                <p className="text-slate-200 mb-6 leading-relaxed italic">
                  "{testimonial.quote}"
                </p>
                <div>
                  <p className="font-semibold text-slate-50">
                    {testimonial.author}
                  </p>
                  <p className="text-sm text-slate-400">{testimonial.role}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section id="contact" className="py-20 px-4 bg-gradient-to-br from-blue-600 to-purple-600">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
            Ready to Start Your Next Project?
          </h2>
          <p className="text-lg text-blue-100 mb-8 max-w-2xl mx-auto">
            Let's work together to create something amazing. Get in touch and
            let's discuss how I can help bring your vision to life.
          </p>
          <button className="px-8 py-4 bg-white text-blue-600 rounded-lg hover:bg-blue-50 transition-colors font-semibold flex items-center justify-center gap-2 mx-auto">
            Start a Conversation
            <ArrowRight className="w-5 h-5" />
          </button>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-slate-950 text-slate-400 py-12 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-4 gap-8 mb-8">
            <div>
              <h3 className="text-slate-100 font-semibold mb-4">Portfolio</h3>
              <p className="text-sm">
                Creating beautiful digital experiences with purpose.
              </p>
            </div>
            <div>
              <h4 className="text-slate-100 font-semibold mb-4">Services</h4>
              <ul className="space-y-2 text-sm">
                <li>
                  <a href="#services" className="hover:text-slate-100 transition">
                    UI/UX Design
                  </a>
                </li>
                <li>
                  <a href="#services" className="hover:text-slate-100 transition">
                    Web Development
                  </a>
                </li>
                <li>
                  <a href="#services" className="hover:text-slate-100 transition">
                    Strategy
                  </a>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="text-slate-100 font-semibold mb-4">Company</h4>
              <ul className="space-y-2 text-sm">
                <li>
                  <a href="#about" className="hover:text-slate-100 transition">
                    About
                  </a>
                </li>
                <li>
                  <a href="#work" className="hover:text-slate-100 transition">
                    Work
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-slate-100 transition">
                    Blog
                  </a>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="text-slate-100 font-semibold mb-4">Connect</h4>
              <ul className="space-y-2 text-sm">
                <li>
                  <a href="#" className="hover:text-slate-100 transition">
                    Twitter
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-slate-100 transition">
                    LinkedIn
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-slate-100 transition">
                    Instagram
                  </a>
                </li>
              </ul>
            </div>
          </div>

          <div className="border-t border-slate-800 pt-8">
            <div className="flex flex-col md:flex-row justify-between items-center">
              <p className="text-sm">
                © 2024 Portfolio. All rights reserved.
              </p>
              <div className="flex gap-6 text-sm mt-4 md:mt-0">
                <a href="#" className="hover:text-slate-100 transition">
                  Privacy Policy
                </a>
                <a href="#" className="hover:text-slate-100 transition">
                  Terms of Service
                </a>
              </div>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
